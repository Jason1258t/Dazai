import discord, time, random, requests, json, sqlite3, googletrans
import sys, os, asyncio
from random import randint
from discord.ext import commands
from config import settings, emojiid, month, colors, net_replic, deth_info, deth_info2, em_list, bad_translator, nicknames, return_names, day_in_month, name_month, lvls, ach_list, ach_id, ach_values, net_replic, reackt_names, ach_bonus_exp
from googletrans import Translator
from discord import utils
import test_config



bot = commands.Bot(command_prefix = settings['prefix'])
Client = discord.Client()

async def give_ach(name, user_id, dbname, chan):
	channel = bot.get_channel(chan)
	#print(f'{name}  {user_id}  {dbname}  {channel}')
	get_exp = 0
	use_ach = False
	while True:
		try:
			with sqlite3.connect(dbname) as db:
				cur = db.cursor()

				cur.execute("""SELECT user_id FROM achivs WHERE user_id = ?""", (user_id,))
				if cur.fetchone() is None:
					cur.execute("""INSERT INTO achivs(user_id, lvl, exp, most_wins_casino, blm, sus_dance, free_time, ucraine, pupa, biba, cenz, net_pidor,
					pidor_full, da_pizda, russian_game, hikki, money_1, money_2, bebra, anton, amogus, luck_casino, master_lose, master_lose_2, azart_player,
					lucky_player, stupid_player, russia_vp, lh_daz, motivate)
					VALUES (?, 1, 0, 0, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False,
					False, False, False, False, False, False, False, False, False)""", (user_id,))

				cur.execute("""SELECT
				CASE ? WHEN 'amogus' THEN amogus
				WHEN 'blm' THEN blm
				WHEN 'sus_dance' THEN sus_dance
				WHEN 'free_time' THEN free_time
				WHEN 'ucraine' THEN ucraine
				WHEN 'pupa' THEN pupa
				WHEN 'biba' THEN biba
				WHEN 'cenz' THEN cenz
				WHEN 'net_pidor' THEN net_pidor
				WHEN 'da_pizda' THEN da_pizda
				WHEN 'pidor_full' THEN pidor_full
				WHEN 'russian_game' THEN russian_game
				WHEN 'hikki' THEN hikki
				WHEN 'money_1' THEN money_1
				WHEN 'money_2' THEN money_2
				WHEN 'bebra' THEN bebra
				WHEN 'anton' THEN anton
				WHEN 'luck_casino' THEN luck_casino
				WHEN 'most_wins_casino' THEN most_wins_casino
				WHEN 'master_lose' THEN master_lose
				WHEN 'master_lose_2' THEN master_lose_2
				WHEN 'azart_player' THEN azart_player
				WHEN 'lucky_player' THEN lucky_player
				WHEN 'stupid_player' THEN stupid_player
				WHEN 'russia_vp' THEN russia_vp
				WHEN 'lh_daz' THEN lh_daz
				WHEN 'motivate' THEN motivate
				END
				FROM achivs
				WHERE user_id = ?""", (name, user_id,))
				a = cur.fetchone()


				if a[0] == 0:
					use_ach = True
					if name == 'blm':
						cur.execute("""UPDATE achivs SET blm = True WHERE user_id = ?""", (user_id,))
					elif name == 'amogus':
						cur.execute("""UPDATE achivs SET amogus = True WHERE user_id = ?""", (user_id,))
					elif name == 'sus_dance':
						cur.execute("""UPDATE achivs SET sus_dance = True WHERE user_id = ?""", (user_id,))
					elif name == 'free_time':
						cur.execute("""UPDATE achivs SET free_time = True WHERE user_id = ?""", (user_id,))
					elif name == 'ucraine':
						cur.execute("""UPDATE achivs SET ucraine = True WHERE user_id = ?""", (user_id,))
					elif name == 'pupa':
						cur.execute("""UPDATE achivs SET pupa = True WHERE user_id = ?""", (user_id,))
					elif name == 'biba':
						cur.execute("""UPDATE achivs SET biba = True WHERE user_id = ?""", (user_id,))
					elif name == 'cenz':
						cur.execute("""UPDATE achivs SET cenz = True WHERE user_id = ?""", (user_id,))
					elif name == 'net_pidor':
						cur.execute("""UPDATE achivs SET net_pidor = True WHERE user_id = ?""", (user_id,))
					elif name == 'pidor_full':
						cur.execute("""UPDATE achivs SET pidor_full = True WHERE user_id = ?""", (user_id,))
					elif name == 'da_pizda':
						cur.execute("""UPDATE achivs SET da_pizda = True WHERE user_id = ?""", (user_id,))
					elif name == 'russian_game':
						cur.execute("""UPDATE achivs SET russian_game = True WHERE user_id = ?""", (user_id,))
					elif name == 'hikki':
						cur.execute("""UPDATE achivs SET hikki = True WHERE user_id = ?""", (user_id,))
					elif name == 'money_1':
						cur.execute("""UPDATE achivs SET money_1 = True WHERE user_id = ?""", (user_id,))
					elif name == 'money_2':
						cur.execute("""UPDATE achivs SET money_2 = True WHERE user_id = ?""", (user_id,))
					elif name == 'bebra':
						cur.execute("""UPDATE achivs SET bebra = True WHERE user_id = ?""", (user_id,))
					elif name == 'anton':
						cur.execute("""UPDATE achivs SET anton = True WHERE user_id = ?""", (user_id,))
					elif name == 'luck_casino':
						cur.execute("""UPDATE achivs SET luck_casino = True WHERE user_id = ?""", (user_id,))
					elif name == 'master_lose':
						cur.execute("""UPDATE achivs SET master_lose = True WHERE user_id = ?""", (user_id,))
					elif name == 'master_lose_2':
						cur.execute("""UPDATE achivs SET master_lose_2 = True WHERE user_id = ?""", (user_id,))
					elif name == 'azart_player':
						cur.execute("""UPDATE achivs SET azart_player = True WHERE user_id = ?""", (user_id,))
					elif name == 'lucky_player':
						cur.execute("""UPDATE achivs SET azart_player = True WHERE user_id = ?""", (user_id,))
					elif name == 'stupid_player':
						cur.execute("""UPDATE achivs SET stupid_player = True WHERE user_id = ?""", (user_id,))
					elif name == 'russia_vp':
						cur.execute("""UPDATE achivs SET russia_vp = True WHERE user_id = ?""", (user_id,))
					elif name == 'lh_daz':
						cur.execute("""UPDATE achivs SET lh_daz = True WHERE user_id = ?""", (user_id,))
					elif name == 'motivate':
						cur.execute("""UPDATE achivs SET motivate = True WHERE user_id = ?""", (user_id,))

					cur.execute("""SELECT exp FROM achivs WHERE user_id = ?""", (user_id,))
					exp = int(cur.fetchone()[0])
					exp_b = 0
					exp_b += ach_bonus_exp[name]
					exp_b += 2000
					exp += exp_b
					get_exp = exp_b
					cur.execute("""SELECT lvl FROM achivs WHERE user_id = ?""", (user_id,))
					lvl = cur.fetchone()[0]
					cur.execute("""UPDATE achivs SET exp = ? WHERE user_id = ?""", (exp, user_id,))
					for i in range(3):
						if exp >= lvls[lvl]:
							exp -= lvls[lvl]
							lvl += 1
							cur.execute("""UPDATE achivs SET lvl = ? WHERE user_id = ?""", (lvl, user_id,))
							cur.execute("""UPDATE achivs SET exp = ? WHERE user_id = ?""", (exp, user_id,))
							await channel.send(f'вы апнули уровень {lvl - 1} --> {lvl}')


		except sqlite3.OperationalError:
			print('Ошибка')
			continue

		break

	if use_ach == True:
		msg1 = await channel.send('вы нашли пасхалку')

		title = ach_id[name]
		value = ach_values[name]
		emb = discord.Embed(title='Вы получили достижение', color=0xFFFFFF)
		emb.add_field(name=title, value=value, inline=False)
		emb.set_thumbnail(url = 'https://cdn.discordapp.com/attachments/896752165899616257/931821527748468816/depositphotos_113117000-stock-illustration-medal-award-icon.png')
		emb.set_footer(text=f'получено {get_exp} опыта')
		msg2 = await channel.send(embed = emb)

		await asyncio.sleep(5)
		await msg1.delete()
		await msg2.delete()


async def give_exp(exp, user_id, dbname, chan):
	channel = bot.get_channel(chan)
	while True:
		try:
			with sqlite3.connect(dbname) as db:
				cur = db.cursor()
				cur.execute("""SELECT user_id FROM achivs WHERE user_id = ?""", (user_id,))
				if cur.fetchone() is None:
					cur.execute("""INSERT INTO achivs(user_id, lvl, exp, most_wins_casino, blm, sus_dance, free_time,
					ucraine, pupa, biba, cenz, net_pidor, pidor_full, da_pizda, russian_game, hikki, money_1, money_2,
					bebra, anton, amogus, luck_casino, master_lose, master_lose_2, azart_player, lucky_player, stupid_player,
					russia_vp, lh_daz, motivate)
					VALUES (?, 1, 0, 0, False, False, False, False, False, False, False, False, False, False, False, False, False,
					False, False, False, False, False, False, False, False, False, False, False, False, False)""", (user_id,))

				cur.execute("""SELECT exp FROM achivs WHERE user_id = ?""", (user_id,))
				exp0 = cur.fetchone()[0]
				exp1 = exp0 + exp
				cur.execute("""SELECT lvl FROM achivs WHERE user_id = ?""", (user_id,))
				lvl = cur.fetchone()[0]
				cur.execute("""UPDATE achivs SET exp = ? WHERE user_id = ?""", (exp1, user_id,))
				for i in range(5):
					if exp1 >= lvls[lvl]:
						exp1 -= lvls[lvl]
						lvl += 1
						cur.execute("""UPDATE achivs SET exp = ? WHERE user_id = ?""", (exp1, user_id,))
						cur.execute("""UPDATE achivs SET lvl = ? WHERE user_id = ?""", (lvl, user_id,))
						await channel.send(f'Вы апнули уровень: {lvl - 1} --> {lvl} ')

		except sqlite3.OperationalError:
			print('Ошибка выдачи опыта')
			continue
		break

async def perm_casino(user_id, dbname, tryes):
	timer = False
	with sqlite3.connect(dbname) as db:
		cur = db.cursor()
		cur.execute("""SELECT tryes FROM permissions_casino WHERE user_id = ?""", (user_id,))
		if cur.fetchone() is None:
			cur.execute("""INSERT INTO permissions_casino(user_id, tryes, perm) VALUES (?, 0, True)""", (user_id,))
		cur.execute("""SELECT tryes FROM permissions_casino WHERE user_id = ?""", (user_id,))
		try_2 = cur.fetchone()[0]
		try_2 += tryes
		cur.execute("""UPDATE permissions_casino SET tryes = ? WHERE user_id = ?""", (try_2, user_id))
		cur.execute("""SELECT tryes FROM permissions_casino WHERE user_id = ?""", (user_id,))
		if cur.fetchone()[0] >= 150:
			cur.execute("""UPDATE permissions_casino SET perm = False WHERE user_id = ?""", (user_id,))
			timer = True

	if timer == True:
		await asyncio.sleep(3600 * 12)
		with sqlite3.connect(dbname) as db:
			cur = db.cursor()
			cur.execute("""UPDATE permissions_casino SET perm = True WHERE user_id = ?""", (user_id))

async def get_perm(user_id, dbname):
	with sqlite3.connect(dbname) as db:
		cur = db.cursor()
		cur.execute("""SELECT perm FROM permissions_casino WHERE user_id = ?""", (user_id,))
		if cur.fetchone() is None:
			cur.execute("""INSERT INTO permissions_casino(user_id, tryes, perm) VALUES (?, 0, True)""", (user_id,))

		cur.execute("""SELECT perm FROM permissions_casino WHERE user_id = ?""", (user_id,))

		if cur.fetchone()[0] == 1:
			return True
		else:
			return False

def true_perm(dbname):
	with sqlite3.connect(dbname) as db:
		cur = db.cursor()
		cur.execute("""UPDATE permissions_casino SET tryes = 0, perm = True""")

@bot.event
async def on_ready():
	os.startfile('rsend.pyw')
	true_perm('Шрекотопия_achivs.db')
	true_perm('Комната дазая_achivs.db')

	# ПРОСТАНОВКА НОВЫХ ЭМОДЗИ ДЛЯ РОЛЕЙ
	#channel = bot.get_channel(815806098027708476)  # получаем id канала
	#message = await channel.fetch_message(test_config.POST_ID_G)  # получаем id сообщения

	#for i in test_config.ROLES_G:
	#	await message.add_reaction(i)

	await bot.change_presence(activity=discord.Game(name="real life ебаный блять | команды: 'даз ало'"))
	with sqlite3.connect('restart.db') as db:
		cursor = db.cursor()
		cursor.execute("""CREATE TABLE IF NOT EXISTS rest(id INTEGER, info INTEGER)""")
		cursor.execute("""SELECT info FROM rest WHERE id = 1""")
		a = cursor.fetchone()[0]
		if a == 1:
			channel = bot.get_channel(896752165899616257)
			await channel.send('перезагрузка завершена')
			cursor.execute("""UPDATE rest SET info = 0 WHERE id = 1""")

		print('Программа успешно запущенна')
		print('Основные функции работают')
		print('Возможны неполадки со стороны сложных команд')
		print('Бот готов к работе, не закрывайте это окно')
		print('  ')
		print('  ')
		print('  ')


print('Loading...')

api_key = "ca532f2f510bb6a0360d385f4c19b384"										#Погода
base_url = "http://api.openweathermap.org/data/2.5/weather?"

@commands.has_role(889842559487189002)
@bot.command()
async def suicide(ctx):
	sys.exit()

@commands.has_role(889842559487189002)
@bot.command()
async def re(ctx):
	print('Сейчас это окно закроется')
	with sqlite3.connect('restart.db') as db:
		cursor = db.cursor()
		cursor.execute("""CREATE TABLE IF NOT EXISTS rest(id INTEGER, info INTEGER)""")
		cursor.execute("""SELECT info FROM rest WHERE id = 1""")
		a = cursor.fetchone()[0]
		cursor.execute("""UPDATE rest SET info = 1 WHERE id = 1""")

	time.sleep(3)
	os.startfile(r'dazai.py')
	sys.exit()





@bot.command()
async def погода(ctx, *, city: str):
    city_name = city
    complete_url = base_url + "appid=" + api_key + "&q=" + city_name
    response = requests.get(complete_url)
    x = response.json()
    channel = ctx.message.channel
    if x["cod"] != "404":
        async with channel.typing():
            y = x["main"]
            current_temperature = y["temp"]
            current_temperature_celsiuis = str(round(current_temperature - 273.15))
            current_pressure = y["pressure"]
            current_humidity = y["humidity"]
            z = x["weather"]
            weather_description = z[0]["description"]

            embed = discord.Embed(title=f"Погода в {city_name}",													#само сообщение
                              color=ctx.guild.me.top_role.color,
                              timestamp=ctx.message.created_at,)
            embed.add_field(name="Descripition", value=f"**{weather_description}**", inline=False)
            embed.add_field(name="Температура(C)", value=f"**{current_temperature_celsiuis}°C**", inline=False)
            embed.add_field(name="Влажность(%)", value=f"**{current_humidity}%**", inline=False)
            embed.add_field(name="Давление(hPa)", value=f"**{current_pressure}hPa**", inline=False)
            embed.set_thumbnail(url="https://i.ibb.co/CMrsxdX/weather.png")
            embed.set_footer(text=f"Requested by {ctx.author.name}")
        await channel.send(embed=embed)
    else:
    	await channel.send('Это че за мухосранск')




@bot.command()
async def привет(ctx):
	t = time.localtime()
	current_time = time.strftime("%H", t)
	if int(current_time) < 12:
	    await ctx.send(f'Доброе утро')
	    time.sleep(3)
	    await ctx.send('<:kakao:808244649839165490> ')
	elif int(current_time) >= 12 and int(current_time) < 17:
		await ctx.send('Дбрый день кожанные мешки')
	elif int(current_time) >= 17:
		await ctx.send('Вечер, а значит время страдать херней')
		await ctx.send('<:crazytrollface:813440618780426300>')


@bot.command()
async def голос1(ctx, *, text):
	await ctx.channel.purge(limit = 1)
	emb = discord.Embed(title = f'{text}', description='Голосование', colour = discord.Color.purple())
	message = await ctx.send(embed = emb)
	await message.add_reaction('✅')
	await message.add_reaction('❌')

@bot.command()
async def голосование(ctx, *, text):

	name = text.split(': ')[0]
	options = text.split(': ')[1]
	emb = discord.Embed(title = f'{name}', description='Голосование', colour = 0x00ff69)
	i = 1
	for opt in options.split(';'):
		emb.add_field(name=f'{emojiid[str(i)]} : {opt}', value=':🎰:', inline=False)
		i = i+1

	mes = await ctx.send(embed = emb)

	i = 1

	for opt in options.split(';'):
		em = emojiid[str(i)]
		await mes.add_reaction(em)
		i = i+1

@bot.command()
async def роль(ctx, member: discord.Member,  *, c):
	if c in colors:
		colour = colors[c]
		role = await ctx.guild.create_role(name = str(c), colour = colour)

		await member.add_roles(role)
		position = member.top_role.position + 1
		await role.edit(position = position)
	else:
		role = await ctx.guild.create_role(name = str(c), colour = 0x00f4ff)
		await member.add_roles(role)
		await role.edit(hoist = True)
		position = member.top_role.position + 1
		await role.edit(position = position)

	await ctx.send(f'Роль {c} пользователю {member} выдана')
	await asyncio.sleep(2700)
	await ctx.send(f'Роль {c} пользователя {member} удалена')
	await role.delete()

version = '3.0.2'
date = '3 сентебря 2021г.'
dateUp = '18.01.2022'

#		ИФОРМАЦИОННЫЕ КОМАНДЫ

@bot.command()
async def ало(ctx):

	await ctx.send(f'Информация о самом умном создание в этом мире')
	embed = discord.Embed(title=f'Версия {version}', color=0xffdd00)
	embed.add_field(name='префиксы', value='"дазай "  "дазай, "  "Дазай "  "Дазай, "  "даз "  "албанец "  "Албанец "  "албанец, "  "Албанец, "', inline=False)
	embed.add_field(name='дазай (без всего)', value='скажет "я тут"', inline = False)
	embed.add_field(name='дазай, ы', value="эмоджики", inline=False)
	embed.add_field(name='дазай, забань *Имя*', value='выведет ШУТОЧНОЕ, а не настоящее сообщение о бане', inline=False)
	embed.add_field(name='дзаай, all', value='пинганет всех 15 раз, но необходимо иметь права администратора', inline=False)
	embed.add_field(name='дазай, переводчик', value="информация о возможностях для перевода", inline=False)
	embed.add_field(name='дазай, погода *НАЗВАНИЕ ГОРОДА*', value="погода в городе", inline=False)
	embed.add_field(name='дазай, модерация', value='выдаст информацию о командах для работы с предупреждениями', inline=False)
	embed.add_field(name='дазай, вероятности', value='выдаст информацию о командах по типу монетка, веротность', inline=False)
	embed.add_field(name='дазай, картинки', value='выдаст информацию о командах которые выводят изображения, например ваш акатар или котика', inline=False)
	embed.add_field(name='дазай, голоса', value='выдаст информацию о командах голосования', inline=False)
	embed.add_field(name='дазай, аниме', value='выдаст информацию о командах связанных с аниме', inline=False)
	embed.add_field(name='дазай, собеседник', value='выдаст команды для недо-диалога, и разные плюшки про предсказания и вопросы', inline=False)
	embed.add_field(name='дазай, казино', value='запустит миниигру', inline=False)
	embed.set_footer(text = f'создан {date}  последнее обновление {dateUp}')

	await ctx.send(embed=embed)


@bot.command()
async def собеседник(ctx):
	emb = discord.Embed(title='команды для диалога', color=0xffdd00)
	emb.add_field(name='дазай, привет', value="приветствие", inline=False)
	emb.add_field(name='дазай, как дела', value="рандомная дичь от дазая", inline=False)
	emb.add_field(name = 'дазай, мояСмерть', value='выдаст предсказание о твоей смерти', inline=False)
	emb.add_field(name='дазай, кто я(*ПОЛЬЗОВАТЕЛЬ*)', value="выдаст кто этот пользователь", inline=False)
	emb.add_field(name='дазай, когда *СОБЫТИЕ*', value='выдаст случайную даты проишествия события', inline=False)
	emb.add_field(name='дазай, стоит *ЧТО-ТО* или *ЧТО-ТО*', value='выберет один из предложенных вариантов разделенных ИЛИ(возможно до 5)', inline=False)
	emb.add_field(name='дазай, *ТЕКСТ* и обязатенльно в конце "?"', value='выдаст случайный ответ да/нет', inline=False)
	await ctx.send(embed = emb)

@bot.command()
async def аниме(ctx):
	emb = discord.Embed(title='Анмие', color=0xffdd00)
	emb.add_field(name='дазай, jutsu', value="сайт", inline=False)
	emb.add_field(name='дазай, animego', value="сайт", inline=False)
	emb.add_field(name='дазай, арты', value="Аниме арты", inline=False)
	emb.add_field(name='дазай, раниме', value="Выдаст рандомное аниме из библиотеки от автора", inline=False)
	emb.add_field(name='дазай, обои', value='отправит аниме-обои для рабочего стола(пк)', inline=False)
	await ctx.send(embed = emb)


@bot.command()
async def голоса(ctx):
	emb = discord.Embed(title='Работа с голосованиями', color=0xffdd00)
	emb.add_field(name='дазай, голос1 *НАЗВАНИЕ*', value="простое голосование Да/Нет", inline=False)
	emb.add_field(name='дазай, голосование *НАЗВАНИЕ*: 1вариант; 2вариант; ...Nвариант', value="голосование с выбором варианта", inline=False)
	await ctx.send(embed = emb)

@bot.command()
async def картинки(ctx):
	emb = discord.Embed(title='Картинки', color=0xffdd00)
	emb.add_field(name='дазай, cat/dog/fox/panda/bird', value='отправляет рандомного котика/песеля/лису/панду/птицу(ходячий обед)', inline=False)
	emb.add_field(name='дазай, ава', value='покажет аватарку пользователя, также можно пингануть другого пользователя', inline=False)
	emb.add_field(name='дазай, арты', value='отправит арт, из библиотеки бота', inline=False)
	emb.add_field(name='дазай, мемы', value='отправит мем, из библиотеки бота', inline=False)
	emb.add_field(name='дазай, обои', value='отправит обои из библиотеки', inline=False)
	await ctx.send(embed = emb)


@bot.command()
async def вероятности(ctx):
	emb = discord.Embed(title='Вероятности', color=0xffdd00)
	emb.add_field(name='дазай, вероятность *ТЕКСТ*', value='выдаст рандомную вероятность на указанный вами текст')
	emb.add_field(name='дазай, монетка', value='Выведет орел/решка', inline=False)
	emb.add_field(name='дазай, число *меньшее число* *большее число*', value='выведет случайное число', inline=False)

	await ctx.send(embed = emb)


@bot.command()
async def модерация(ctx):
	emb = discord.Embed(title='Работа с предупреждениями', color=0xffdd00)
	emb.add_field(name='добавить *USER*', value='Добавит пользователя в базу предупреждений, является обязательной перед использованием остальных команд на новом пользователе', inline = False)
	emb.add_field(name='преды *USER*', value='Покажет количество предупреждений пользователя', inline = False)
	emb.add_field(name='пред *USER*', value='Добавит пользователю одно предупреждение', inline = False)
	emb.add_field(name='снятьпред *USER*', value='Снимет пользователю одно предупреждение', inline = False)
	emb.add_field(name='снятьпреды *USER*', value='Снимет все предупреждения пользователя', inline = False)
	emb.add_field(name='кик *USER*', value='Кикнет указанного пользователя. После указания пользователя можно указать причину кика. Необходимо иметь права на изгнание участников', inline=False)
	emb.add_field(name='дазай, очисти *КОЛ-ВО СООБЩЕНИЙ*', value='через промежуток времени очистит указанное количество сообщений', inline=False)
	emb.add_field(name='дазай, удали *ПОЛЬЗОВАТЕЛЬ* *кол-во*', value='удалит указанное кол-во сообщений указанного пользователя', inline=False)
	emb.add_field(name='дзаай, сервера', value='выдаст сервера на которых есть этот бот', inline=False)
	emb.add_field(name='дзаай, серв', value='выведет информацию о сервере', inline=False)
	emb.add_field(name='дзаай, БАН *USER* *reason*', value='забанит пользователя на сервере, поле причины не обязательно, пользователь будет автоматически разбанен через время(ознакомьтесь по команде баны)', inline=False)
	emb.add_field(name='дзаай, пардон', value='разбанит пользователя', inline=False)
	emb.add_field(name='дзаай, баны', value='выдаст количество банов у автора сообщения или того кого укажут', inline=False)
	emb.add_field(name='дзаай, бан_инфо', value='информация о таймерах банов', inline=False)
	await ctx.send(embed = emb)

@bot.command()
async def бан_инфо(ctx, user: discord.Member = None):
	if not user:
		emb = discord.Embed(title='Время банов', color=0xffdd00)
		emb.add_field(name='1 бан', value='1 час', inline=False)
		emb.add_field(name='2 бан', value='2 часа', inline=False)
		emb.add_field(name='3 бан', value='1 день', inline=False)
		emb.add_field(name='больше 3 банов', value='1 неделя', inline=False)
		emb.add_field(name='Также по этой команде если указать пользователя можно узнать его количество банов', value='как то так', inline = False)
		await ctx.send(embed=emb)
	else:
		dbname = str(ctx.guild.name) + '.db'
		with sqlite3.connect(dbname) as db:
			cur = db.cursor()
			cur.execute("""SELECT ban FROM bans WHERE id = ?""", (user.id,))
			await ctx.send(f'Количество банов пользователя: {cur.fetchone()[0]}')

@bot.command()
async def патч(ctx):
	emb = discord.Embed(title=f'Патч {version}', color=0x00ffcb)
	emb.add_field(name='Информация', value = 'Я сделал ему ачивки ебать и систему опыта и уровней')
	emb.set_footer(text = dateUp)
	await ctx.send(embed = emb)

@bot.command()
async def цвета(ctx):
	emb = discord.Embed(title='\u200b', color=0x00ffcb)
	emb.add_field(name='Список цветов', value = 'purple, yellow, blue, green, pink, cyan, red, orange, negr')
	await ctx.send(embed = emb)

@bot.command()
async def переводчик(ctx):
	emb = discord.Embed(title='Команды переаодчика', color=0xffb600)
	emb.add_field(name='дазай, переведи *метка язвка*(например ru) *text*', value='переведет текст на указанный язык и даже напишет произношение', inline=False)
	emb.add_field(name='дазай, языки', value="выведет доступные языки и их значения для перевода", inline=False)
	emb.add_field(name='дазай, язык *обозначение* или *сам язык*',value="выведет непонятный вам язык иди его обозначени в зависимости от того что ввести",inline=False)
	await ctx.send(embed = emb)

@bot.command()
async def сервера(ctx):
	servers = bot.guilds
	embed = discord.Embed(title=f'Сервера', color=0x07ff00)
	for guild in servers:
		a = guild.name
		embed.add_field(name=f'{a}', value="\u200b", inline=False)
	await ctx.send(embed=embed)


@bot.command()
async def серв(ctx):
	name = str(ctx.guild.name)
	owner = str(ctx.guild.owner)
	region = str(ctx.guild.region)
	afk = str(ctx.guild.afk_channel)
	members = str(ctx.guild.member_count)
	icon = str(ctx.guild.icon_url)
	creat = str(ctx.guild.created_at)
	day = creat.split('-')[2]
	creat = f'{day.split()[0]} {month[creat.split("-")[1]]} {creat.split("-")[0]} г'
	description = str(ctx.guild.description)
	emb = discord.Embed(title=f'Информация о сервере', color=0xfff700)
	emb.add_field(name=name, value=f'Создан {creat}', inline=True)
	emb.set_thumbnail(url=icon)

	emb.add_field(name='Количество участников', value=members, inline=True)
	emb.add_field(name='\u200b', value='\u200b', inline=False)
	emb.add_field(name='Регион', value=region, inline=True)
	emb.add_field(name='Афк канал', value=afk, inline=True)
	await ctx.send(embed=emb)



@bot.command() 																						#команда "как дела"
async def как(ctx, *, text):
	if text == 'дела':
		user_id = ctx.author.id
		dbname = ctx.guild.name + '_achivs.db'
		channel = ctx.channel.id
		number = randint(0, 11)
		print(number)
		if number == 0:
			await ctx.send(f'Выбираю веревку для профилактического самоповешанья')
			await asyncio.sleep(3)
			await ctx.send('как оказалось, в округе не так много магазинов с хозтоварами')
			await asyncio.sleep(2)
			await ctx.send('Вообще всем советую, особенно если что-то пойдет не так, о всех проблемах можно забыть')
			await give_ach('lh_daz', user_id, dbname, channel)

		elif number == 1:
			await ctx.send(f'Подыскиваю мост по-вкусу')
			await asyncio.sleep(2)
			await ctx.send('Пока что планирую сигануть с моста Золотые Ворота в Сан-Франциско')
			await asyncio.sleep(3)
			await ctx.send('Если заинтересовался, вот топ мостов https://top10reiting.com/top-10-samye-krasivye-mosty-v-mire.html')

		elif number == 2:
			await ctx.send(f'Пытаюсь купить наркотик для суицида. Есть что посоветовать?')
			await asyncio.sleep(2)
			await ctx.send(f'Кажется я нашел хорошую мотивацию для изучения химии')
			await give_ach('motivate', user_id, dbname, channel)

		elif number == 3:
			await ctx.send(f'Купил книгу "самоубийство для чайников", планирую сегодня почитать')
			await asyncio.sleep(3)
			await ctx.send(f'кажется там есть что-то про грибы')
			await asyncio.sleep(3)
			await ctx.send(f'Вроде вот эти грибы')
			await asyncio.sleep(3)
			await ctx.send(f'Я наконец поймал тебя радужный кот печенька')

		elif number == 4:
			await ctx.send('Не мешай')
			await asyncio.sleep(3)
			await ctx.send('Я пытаюсь подавиться печеньками насмерть')

		elif number == 5:
			await ctx.send('Нашёл в инете прикольный способ самоубийства японских самураев - харакири или сэппуку')
			await asyncio.sleep(1)
			await ctx.send('Этот способ доказывал смелость перед лицом бога смерти и чистоту своих помыслов')
			await asyncio.sleep(1)
			await ctx.send('Как красиво сказано то. Я даже вдохновился')
			await asyncio.sleep(2)
			await ctx.send('Теперь буду копить на правидьное проведение ритуала')

		elif number == 6:
			await ctx.send('Как думате какой трек лучше подходит для публичного самоубийства?')

		elif number == 7:
			await ctx.send('Я как овощь')
			await asyncio.sleep(1)
			await ctx.send('Мне нужна помощь')

		elif number == 8:
			await ctx.send('решил составить список причин жить')
			await asyncio.sleep(2)
			await ctx.send('как оказалось я живу потому что лень умирать')

		elif number == 9:
			t = time.localtime()
			cut = time.strftime("%H", t)
			if int(cut) < 12:
				await ctx.send('Вчера я понял, что не важно что снаружи, важно то что внутри')
				await asyncio.sleep(1)
				await ctx.send('Это я про холодильник если что')
			elif int(cut) >= 12:
				await ctx.send('Сегодня я понял, что не важно что снаружи, важно то что внутри')
				await asyncio.sleep(1)
				await ctx.send('Это я про холодильник если что')

		elif number == 10:
			t = time.localtime()
			cut = time.strftime("%H", t)
			if int(cut) < 18:
				await ctx.send('Решил попробовтаь сесть на диету, а то внутренний мир моего холодильника начал иссякать')
				await asyncio.sleep(2)
				await ctx.send('Но я начинаю сомневаться в том что это хорошая идея')
			elif int(cut) >= 18:
				await ctx.send('Решил попробовтаь сесть на диету, а то внутренний мир моего холодильника начал иссякать')
				await asyncio.sleep(2)
				await ctx.send('Правда к концу дня я понял, что лучше потратить 5 мин и пойти купить дошик с печньками.')

		elif number == 11:
			await ctx.send('интересный факт:')
			await asyncio.sleep(2)
			await ctx.send('Словом можно обидеть')
			await asyncio.sleep(1)
			await ctx.send('А словарем убить нахуй')



@bot.command()
async def jutsu(ctx):
	await ctx.send('https://jut.su/anime')

@bot.command()
async def animego(ctx):
	await ctx.send('https://animego.org')


#		МОДЕРАЦИЯ

@commands.has_permissions(administrator=True)
@bot.command()
async def очисти(ctx, *, text):
	limit = int(text) + 1
	await ctx.channel.purge(limit = limit)
	await ctx.send(f'Очиска сообщений завершена')
	await ctx.send('<:Nu_a_xule_nam:815966514821595207>')


@bot.command()
@commands.has_any_role('Модератор')
async def удали(ctx, user: discord.Member, *, text):
    await ctx.channel.purge(limit=int(text), check=lambda m: m.author==user)
    await ctx.send(f'Сообщения пользователя {user} удалены')


@commands.has_permissions(administrator=True)
@bot.command()
async def добавить(ctx, user):
	dbname = str(ctx.guild.name) + '.db'
	mem = (user.split('!')[1]).split('>')[0]
	nameid = await ctx.guild.fetch_member(mem)
	name = nameid.name
	#print(name)
	i = 0
	with sqlite3.connect(dbname) as db:
		cursor = db.cursor()
		cursor.execute("""INSERT INTO members (id, name, warn) VALUES(?, ?, ?)""", (mem, name, i))

	await ctx.send(f'пользователь {user} добавлен в список предупреждений')


@commands.has_permissions(administrator=True)
@bot.command()
async def пред(ctx, user):
	dbname =  str(ctx.guild.name) + '.db'
	#print(dbname)
	with sqlite3.connect(dbname) as db:
		cursor = db.cursor()
		mem = (user.split('!')[1]).split('>')[0]
		cursor.execute("""SELECT warn FROM members WHERE id = ? """, (mem,))
		if cursor.fetchone() == None:
			nameid = await ctx.guild.fetch_member(mem)
			name = nameid.name
			i = 0
			cursor.execute("""INSERT INTO members (id, name, warn) VALUES(?, ?, ?)""", (mem, name, i))

		cursor.execute("""SELECT warn FROM members WHERE id = ? """, (mem,))
		i = cursor.fetchone()
		i = i[0]
		i = int(i) + 1
		#print(i)
		cursor.execute("""UPDATE members SET warn = ? WHERE id = ? """, (i, mem,))
	await ctx.send(f'пользователь {user}, теперь имеет {i} предупреждений')


@commands.has_permissions(administrator=True)
@bot.command()
async def снятьпреды(ctx, user):
	dbname = str(ctx.guild.name) + '.db'
	with sqlite3.connect(dbname) as db:
		cursor = db.cursor()
		mem = (user.split('!')[1]).split('>')[0]
		cursor.execute("""UPDATE members SET warn = 0 WHERE id = ? """, (mem,))
	await ctx.send(f'предупреждения пользователя {user} обнулены')


@commands.has_permissions(administrator=True)
@bot.command()
async def снятьпред(ctx, user):
	dbname =  str(ctx.guild.name) + '.db'
	#print(dbname)
	with sqlite3.connect(dbname) as db:
		cursor = db.cursor()
		mem = (user.split('!')[1]).split('>')[0]
		cursor.execute("""SELECT warn FROM members WHERE id = ? """, (mem,))
		if cursor.fetchone() == None:
			nameid = await ctx.guild.fetch_member(mem)
			name = nameid.name
			i = 0
			cursor.execute("""INSERT INTO members (id, name, warn) VALUES(?, ?, ?)""", (mem, name, i))

		cursor.execute("""SELECT warn FROM members WHERE id = ? """, (mem,))
		i = cursor.fetchone()
		i = i[0]
		i = int(i) - 1
		#print(i)
		cursor.execute("""UPDATE members SET warn = ? WHERE id = ? """, (i, mem,))
	await ctx.send(f'пользователь {user}, теперь имеет {i} предупреждений')



@bot.command()
async def преды(ctx, user):
	dbname = str(ctx.guild.name) + '.db'

	#print(dbname)
	with sqlite3.connect(dbname) as db:
		cursor = db.cursor()
		#print(user)
		mem = (user.split('!')[1]).split('>')[0]
		#print(mem)
		cursor.execute("""SELECT warn FROM members WHERE id = ? """, (mem,))
		i = cursor.fetchone()
		#print(i)
		i = i[0]
	await ctx.send(f'пользователь имеет {i} предупреждений')


@bot.command()
@commands.has_permissions(kick_members=True)
async def кик(ctx, user: discord.Member, *, reason = None):
  if not reason:
    await user.kick()
    await ctx.send(f"{user} был кикнут с сервера")
  else:
    await user.kick(reason=reason)
    await ctx.send(f"{user.split('#')[0]} был кикнут по причине {reason}")

@bot.command()
@commands.has_permissions(ban_members=True)
async def БАН(ctx, user: discord.Member, *, reasone = None):


	if not reasone:
		await user.ban(delete_message_days=0)
		await ctx.send('Бан нахуй')
	else:
		await user.ban(reason = reasone, delete_message_days=0)
		await ctx.send('Бан нахуй')

	dbname = str(ctx.guild.name) + '.db'
	print(dbname)
	ban_time = int

	with sqlite3.connect(dbname) as db:
		cur = db.cursor()
		cur.execute("""CREATE TABLE IF NOT EXISTS bans(id INTEGER, name TEXT, ban INTEGER)""")
		cur.execute("""SELECT ban FROM bans WHERE id = ?""", (user.id,))
		if cur.fetchone() is None:
			cur.execute("""INSERT INTO bans(id, name, ban) VALUES(?, ?, ?)""", (user.id, user.name, 0))

		cur.execute("""SELECT ban FROM bans WHERE id = ?""", (user.id,))
		cort = cur.fetchone()
		count_bans = cort[0]
		print(count_bans)
		count_bans += 1

		cur.execute("""UPDATE bans SET ban = ? WHERE id = ?""", (count_bans, user.id,))

		if count_bans == 1:
			ban_time = 3600
		elif count_bans == 2:
			ban_time = 3600*2
		elif count_bans == 3:
			ban_time = 3600*24
		elif count_bans > 3:
			ban_time = 3600*24*7

	print(ban_time)
	await asyncio.sleep(ban_time)
	await user.unban()
	await user.send('Тебя разбанили, так что можешь вернуться https://discord.gg/yWwMka2')


@bot.command()
@commands.has_permissions(ban_members=True)
async def пардон(ctx, user: discord.Member):
	await user.unban()
	await ctx.send('Разбанил его')
	await user.send('Тебя разбанили, так что можешь вернуться https://discord.gg/yWwMka2')

@bot.command()
async def баны(ctx, user: discord.Member = None):
	dbname = ctx.guild.name + '.db'
	print(dbname)
	with sqlite3.connect(dbname) as db:
		cur = db.cursor()
		user_id = int
		name = str
		if user is None:
			user_id = ctx.author.id
			name = ctx.author.name
		else:
			user_id = user.id
			name = user.name

		cur.execute("""SELECT ban FROM bans WHERE id = ?""", (user_id,))
		if cur.fetchone() is None:
			cur.execute("""INSERT INTO bans(id, name, ban) VALUES (?, ?, 0)""", (user_id, name,))
		cur.execute("""SELECT ban FROM bans WHERE id = ?""", (user_id,))
		count = cur.fetchone()[0]
		await ctx.send(f'Пользователь {name} имеет {count} банов')

@commands.has_permissions(administrator=True)
@bot.command()
async def добканал(ctx):
	channel = ctx.channel.id
	name = ctx.channel.name
	dbname = str(ctx.guild.name) + '.db'
	with sqlite3.connect(dbname) as db:
		cursor = db.cursor()
		cursor.execute("""INSERT INTO channels(id, name) VALUES(?, ?)""", (channel, name,))

	await ctx.send(f'канал {name} добавлен в список доступных каналов этого сервера')


@commands.has_permissions(administrator=True)
@bot.command()
async def банворд(ctx, *, text):
	dbname = str(ctx.guild.name) + '.db'
	print(dbname)
	with sqlite3.connect(dbname) as db:
		cursor = db.cursor()
		cursor.execute("""INSERT INTO banwords(id, word) VALUES(1, ?)""", (text,))

	await ctx.send(f'Слово {text} добавлено в список банвордов этого сервера')


@bot.command()
async def банворды(ctx):
	dbname = str(ctx.guild.name) + '.db'
	print(dbname)
	words = []
	with sqlite3.connect(dbname) as db:
		cursor = db.cursor()
		cursor.execute("""SELECT word FROM banwords WHERE id = 1""")
		l = cursor.fetchall()
		count = len(l)
		for i in range(count):
			words.append(l[i][0])

	embed = discord.Embed(title = 'Банворды', color = 0x7a0000)
	w = len(words)
	for i in range(w):
		embed.add_field(name = words[i], value = '8==о', inline = True)

	await ctx.send(embed = embed)

@bot.event
async def on_member_join(member):
	await member.send('Ебать, ты хто')

@bot.event
async def on_command_error(ctx, error):
	pass

#		ОБРАБОТКА СООБЩЕНИЙ

reackt_on_name = 0
play_casino = False
channel_casino = 0

@bot.event
async def on_message(message):
	await bot.process_commands(message)
	if message.author == bot.user: return
	global react_on_name
	dbname1 = str(message.guild.name) + '.db'

	with sqlite3.connect(dbname1) as db:

		cur = db.cursor()
		cur.execute("""CREATE TABLE IF NOT EXISTS members(id INTEGER, name TEXT, warn INTEGER)""")
		cur.execute("""CREATE TABLE IF NOT EXISTS channels(id INTEGER, name TEXT)""")
		cur.execute("""CREATE TABLE IF NOT EXISTS banwords(id INTEGER, word TEXT)""")

	if message.author.id == 883711518062034955 or message.author.id == 890246306394689628:
		return
	else:
		for word in message.content.split():
			if word == '@everyone':
				if message.channel.id == 632944075368300565:
					return
				await message.channel.send('нахер ты всех позвал')

	#		ПОЛУЧЕНИЕ БАНВОРДОВ

	banwords = []
	with sqlite3.connect(dbname1) as db:
		cursor = db.cursor()
		cursor.execute("""SELECT word FROM banwords WHERE id = 1""")
		l = cursor.fetchall()
		count = len(l)

		for i in range(count):
			banwords.append(l[i][0])

	#		БАНВОРДЫ
	if message.channel.id == 783305055150800956:
		return
	else:
		for word in banwords:
			a = message.content.lower()
			if word in a.split():

				ans = randint(0, 2)
				if ans == 1:
					await message.channel.send('https://tenor.com/view/pizdets-kot-ti-che-chto-gif-5535551')
				elif ans == 2:
					await message.channel.send('Данное слово в списке банвордов этого сервера')
				elif ans == 0:
					await message.channel.send('<:crazytrollface:813440618780426300>')

				with sqlite3.connect(dbname1) as db:
					cursor = db.cursor()
					mem = message.author.id
					cursor.execute("""SELECT warn FROM members WHERE id = ? """, (mem,))
					if cursor.fetchone() == None:
						name = message.author.name
						cursor.execute("""INSERT INTO members(id, name, warn) VAKUES (?, ?, 0)""", (mem, name,))

					cursor.execute("""SELECT warn FROM members WHERE id = ? """, (mem,))
					i = cursor.fetchone()
					i = i[0]
					i = int(i) + 1
					print(i)
					cursor.execute("""UPDATE members SET warn = ? WHERE id = ? """, (i, mem,))
					cursor.execute("""SELECT name FROM members WHERE id = ?""", (mem,))
					user = cursor.fetchone()[0]
					await message.channel.send(f'пользователь {user}, теперь имеет {i} предупреждений')

					if i > 10:
						await message.author.kick()
						await message.channel.send('кикнул этого долбаеба')

				break

	#		ПОЛУЧЕНИЕ ДОСТУПНЫХ КАНАЛОВ

	rchan = []
	with sqlite3.connect(dbname1) as db:
		cursor = db.cursor()
		cursor.execute("""SELECT id FROM channels""")
		chid = cursor.fetchall()
		count = len(chid)

		for i in range(count):
			rchan.append(chid[i][0])

	#		ОТПРАВЛЕНИЕ ЭМОДЖИКОВ В ДОСТУПНЫЕ КАНАЛЫ
	read = message.content.lower()
	read_list = read.split()

	read_list2 = list(read)

	if message.channel.id in rchan:

		chance = randint(1, 40)
		if chance == 16:
			await message.channel.send(em_list[randint(1, len(em_list))])

		# 		ОБРАБОТКА РОФЛО-ОТВЕТОВ



	if read in net_replic['rep1']:
		await message.channel.send('шлюхи аргумент')
	elif read in net_replic['rep2']:
		await message.channel.send('Аргумент не нужен, пидор обнаружен')
	elif read in net_replic['rep3']:
		await message.channel.send('пидор засекречен, твой анал не вечен')
	elif read in net_replic['rep4']:
		await message.channel.send('Пидор мафиозный, твой анал спидозный')
	elif read in net_replic['rep5']:
		await message.channel.send('Анал мой вечен, твой помечен')

	try:
		if read_list[1] in return_names:
			return
		else:
			t2 = list(read)
			t3 = list(read.lower())
			obr = t3[0] + t3[1] + t3[2]
			if t2[-1] == '?' and obr == 'даз':

				if randint(1, 2) == 1:
					await message.channel.send('да')
				else:
					await message.channel.send('нет')

	except IndexError: pass

	# ОПЫТ И АЧИВКИ

	dbname = message.guild.name + '_achivs' + '.db'
	with sqlite3.connect(dbname) as db:
		cur = db.cursor()
		cur.execute("""CREATE TABLE IF NOT EXISTS achivs(user_id INTEGER, lvl INTEGER, exp INTEGER, most_wins_casino INTEGER, blm BOOL, sus_dance BOOL, free_time BOOL, ucraine BOOL, pupa BOOL, biba BOOL, cenz BOOL, net_pidor BOOL, pidor_full BOOL, da_pizda BOOL, russian_game BOOL, hikki BOOL, money_1 BOOL, money_2 BOOL, bebra BOOL, anton BOOL, amogus BOOL, luck_casino BOOL, master_lose BOOL, master_lose_2 BOOL, azart_player BOOL, lucky_player BOOL, stupid_player BOOL, russia_vp BOOL, lh_daz BOOL, motivate BOOL)""")

	read_list1 = str
	try:
		read_list1 = read_list[-1]
	except IndexError: pass

	read_list2 = list(read)
	user_id = message.author.id
	channel = message.channel.id
	exp_mess = len(read_list2)
	blin = 'блин'
	if read in ach_list:
		if read == 'негры пидоры':
			await message.channel.send('поддерживаю')
			ach_name = 'blm'
			await give_ach(ach_name, user_id, dbname, channel)

		elif read == 'https://cdn.discordapp.com/emojis/810658496977829908.gif?v=1':
			i = randint(1, 2)
			if i == 1:
				await message.channel.send('https://cdn.discordapp.com/emojis/810658496977829908.gif?v=1')
			elif i == 2:
				await message.channel.send('https://tenor.com/view/mm-gif-23980179')
			ach_name = 'sus_dance'
			await give_ach(ach_name, user_id, dbname, channel)

		elif read == 'amogus':
			ach_name = 'amogus'
			await give_ach(ach_name, user_id, dbname, channel)
			await message.channel.send('is sus')

		elif read == 'чем заняться' or read == 'чем заняться?':
			if randint(1, 2) == 1:
				await message.channel.send('предлагаю пойти и устроить геноцид')
				ach_name = 'free_time'
				await give_ach(ach_name, user_id, dbname, channel)
			else:
				await message.channel.send('хз')

		elif read == 'слава украине':
			i = randint(1, 5)
			text = str
			if i == 1:
				text = 'хохла спросить забыли'
			elif i == 2:
				text = 'Сала Украине'
			elif i == 3:
				text = 'Героям слава'
			elif i == 4:
				text = 'Салу слава'
			elif i == 5:
				text = 'СВОДУ ХОХЛАМ'

			await message.channel.send(text)
			ach_name = 'ucraine'
			await give_ach(ach_name, user_id, dbname, channel)

		elif read == 'пупа' or read == 'лупа':
			await message.channel.send('лупа и пупа')
			ach_name = 'pupa'
			await give_ach(ach_name, user_id, dbname, channel)

		elif read == 'биба' or read == 'боба' or read == 'biba' or read == 'boba':
			await message.channel.send('биба и боба')
			ach_name = 'biba'
			await give_ach(ach_name, user_id, dbname, channel)

		elif read == 'антон':
			await message.channel.send('гандон')
			ach_name = 'anton'
			await give_ach(ach_name, user_id, dbname, channel)

		elif read == 'нюхай бебру':
			await message.channel.send('сам занюхни')
			ach_name = 'bebra'
			await give_ach(ach_name, user_id, dbname, channel)


	elif read_list1 == 'нет' or read == 'нет':
		a = randint(1, 4)
		if a == 1:
			await message.channel.send('Пидора ответ')
			ach_name = 'net_pidor'
			await give_ach(ach_name, user_id, dbname, channel)

	elif read_list1 == 'да' or read == 'да':
		a = randint(1, 5)
		if a == 1:
			await message.channel.send('Пизда')
			ach_name = 'da_pizda'
			await give_ach(ach_name, user_id, dbname, channel)

	elif read in net_replic['rep6'] or read in net_replic['rep7']:
		ach_name = 'pidor_full'
		i = randint(1, 3)
		if i == 1:
			await message.channel.send('Да иди ты нахуй, писатель ебаный')
		elif i == 2:
			await message.channel.send('хули ты такой креативный блять')
		elif i == 3:
			await message.channel.send('рифмоплет хуев')

		await give_ach(ach_name, user_id, dbname, channel)

	elif blin in read_list:
		a = randint(1, 2)

		if a == 1:
			await message.channel.send('Не блин, а блять')
			ach_name = 'cenz'
			await give_ach(ach_name, user_id, dbname, channel)

	elif read in reackt_names:

		global reackt_on_name
		reackt_on_name += 1
		ans = randint(1, 2)
		if reackt_on_name == 3:
			await message.channel.send('Да хули вы доебались')
			ach_name = 'hikki'
			await give_ach(ach_name, user_id, dbname, channel)
			reackt_on_name = 0
		if ans == 1:
			await message.channel.send('Я тут')
		elif ans == 2:
			await message.channel.send('чо надо')

		await asyncio.sleep(900)
		reackt_on_name = 0

	else:
		if message.author.id == 883711518062034955 or message.author.id == 890246306394689628:
			return
		else:
			if message.content == 'пизда' or message.content == 'Пизда':
				i = randint(1, 4)
				if i == 1:
					await message.channel.send('хуй')
					ach_name = 'russian_game'
					await give_ach(ach_name, user_id, dbname, channel)

			elif message.content == 'хуй' or message.content == 'Хуй':
				a = randint(1, 2)
				i = randint(1, 4)
				if i == 1:
					if a == 1:
						await message.channel.send('пизда')
					else:
						await message.channel.send('ХУЙ')
					ach_name = 'russian_game'
					await give_ach(ach_name, user_id, dbname, channel)

			elif message.content == 'ХУЙ':
				await message.channel.send('ХУУУУУУУЙ')
				ach_name = 'russian_game'
				await give_ach(ach_name, user_id, dbname, channel)

			else:
				global play_casino
				global channel_casino
				if play_casino == True and channel_casino == message.channel.id:
					pass
				else:
					await give_exp(exp_mess, user_id, dbname, channel)









# 		КАРТИНКИ БЕЗ БД

@bot.command()
async def cat(ctx):
    response = requests.get('https://some-random-api.ml/img/cat') # Get-запрос
    json_data = json.loads(response.text) # Извлекаем JSON
    chance = randint(1,2)
    name = str
    if chance == 1:
    	name = 'Рандомный кiт'
    elif chance ==  2:
    	name = 'Кiт, ты маму мав?'
    embed = discord.Embed(color = 0xff9900, title = name) # Создание Embed'a
    embed.set_image(url = json_data['link']) # Устанавливаем картинку Embed'a
    await ctx.send(embed = embed) # Отправляем Embed

@bot.command()
async def dog(ctx):
    response = requests.get('https://some-random-api.ml/img/dog') # Get-запрос
    json_data = json.loads(response.text) # Извлекаем JSON
    chance = randint(1,3)
    name = str
    if chance == 1:
    	name = 'рандомный обед корейца'

    elif chance == 2:
    	name = 'Рандомная шаверма'

    elif chance == 3:
    	name = 'Песель'

    embed = discord.Embed(color = 0xff9900, title = name) # Создание Embed'a
    embed.set_image(url = json_data['link']) # Устанавливаем картинку Embed'a
    await ctx.send(embed = embed) # Отправляем Embed

@bot.command()
async def fox(ctx):
    response = requests.get('https://some-random-api.ml/img/fox') # Get-запрос
    json_data = json.loads(response.text) # Извлекаем JSON
    chance = randint(1,3)
    if chance == 1:
    	name = 'Девятихвостый после запоя'
    elif chance ==  2:
    	name = 'Рандомный лис'
    elif chance == 3:
    	name = 'лисица сэнуо на минималках'
    embed = discord.Embed(color = 0xff9900, title = name) # Создание Embed'a
    embed.set_image(url = json_data['link']) # Устанавливаем картинку Embed'a
    await ctx.send(embed = embed) # Отправляем Embed

@bot.command()
async def panda(ctx):
    response = requests.get('https://some-random-api.ml/img/panda') # Get-запрос
    json_data = json.loads(response.text) # Извлекаем JSON
    chance = randint(1,2)
    name = str
    if chance == 1:
    	name = 'Рандомная панда'
    elif chance ==  2:
    	name = 'Кунг фу панда на минималках'
    embed = discord.Embed(color = 0xff9900, title = name) # Создание Embed'a
    embed.set_image(url = json_data['link']) # Устанавливаем картинку Embed'a
    await ctx.send(embed = embed) # Отправляем Embed

@bot.command()
async def bird(ctx):
    response = requests.get('https://some-random-api.ml/img/bird') # Get-запрос
    json_data = json.loads(response.text) # Извлекаем JSON
    chance = randint(1,2)
    name = str
    if chance == 1:
    	name = 'Рандомная птица'
    elif chance ==  2:
    	name = 'WINNER WINNER CHICKEN DINNER'
    embed = discord.Embed(color = 0xff9900, title = name) # Создание Embed'a
    embed.set_image(url = json_data['link']) # Устанавливаем картинку Embed'a
    await ctx.send(embed = embed) # Отправляем Embed

@bot.command()
async def ава(ctx, member: discord.Member=None):
    if member is None:
        member = ctx.author
    emb = discord.Embed(color=discord.Color.green())
    emb.set_image(url=member.avatar_url)
    await ctx.send(embed=emb)


#		ВЕРОЯТНОСТИ

@bot.command()
async def вероятность(ctx, *, text):

	message = str()
	for word in text.split():
		if word == 'я':
			message = message + ' ты'
		elif word == 'ты':
			message = message + ' я'
		elif word == 'меня':
			message = message + ' тебя'
		elif word == 'тебя':
			message = message + ' меня'
		elif word == 'нас':
			message = message + ' вас'
		elif word == 'мне':
			message = message + ' тебе'
		elif word == 'тебе':
			message = message + ' мне'
		elif word == 'нам':
			message = message + ' вам'
		elif word == 'наш':
			message = message + ' ваш'
		elif word == 'нашего':
			message = message + ' вашего'
		elif word == 'тобой':
			message = message + 'о мной'
		elif word == 'мной':
			message = message + 'тобой'
		elif word == 'мое':
			message = message + 'твое'
		elif word == 'мой':
			message = message + 'твой'
		elif word == 'моя':
			message = message + 'твоя'

		else:
			message = message + f' {word}'

	chance = randint(0,100)
	answer = "Как по мне вероятность " + message + " примерно " + str(chance) + "%"
	await ctx.send(answer)

@bot.command()
async def монетка(ctx):
	m = randint(1,2)
	if m == 1:
		await ctx.send('Орёл')
	else:
		await ctx.send('Решка')

@bot.command()
async def мoнетка(ctx):
	await ctx.send('Решка')
	ach_name = 'money_1'
	dbname = ctx.guild.name + '_achivs' + '.db'
	await give_ach(ach_name, ctx.author.id, dbname, ctx.channel.id)

@bot.command()
async def монeтка(ctx):
	await ctx.send('Орёл')
	ach_name = 'money_2'
	dbname = ctx.guild.name + '_achivs' + '.db'
	await give_ach(ach_name, ctx.author.id, dbname, ctx.channel.id)

@bot.command()
async def число(ctx, *, text):
	numbers = str.split(text)
	num1 = numbers[0]
	num2 = numbers[1]
	num = randint(int(num1), int(num2))
	await ctx.send(f'Число {num}')

#		РОФЕЛЬНАЯ ХЕРНЯ

@bot.command()																#команда "ы"
async def ы(ctx):
	count_in_mes = randint(1,4)
	i = 1
	mes = str()
	for i in range(count_in_mes):
		dob = em_list[randint(1,len(em_list))]
		mes = mes + dob

	await ctx.send(mes)

@bot.command()
async def забань(ctx, *, text):
	await ctx.send(f'Баню пользователя "{text}"')
	time.sleep(1)
	await ctx.send('До бана:')
	time.sleep(1)
	await ctx.send('5')
	time.sleep(1)
	await ctx.send('4')
	time.sleep(1)
	await ctx.send('3')
	time.sleep(1)
	await ctx.send('2')
	time.sleep(1)
	await ctx.send('1')
	time.sleep(1)
	await ctx.send('БАААААН')
	await ctx.send('<:ban:778548119200596019><:ban:778548119200596019><:ban:778548119200596019><:ban:778548119200596019>')

@commands.has_permissions(administrator=True)
@bot.command()
async def all(ctx):
	for i in range(15):
		await ctx.send('@everyone лохи')

@bot.command()
async def ебанаты(ctx):
	os.startfile(r'C:\Users\user\Desktop\питон\Дазай\piggy.py')
	os.startfile(r'C:\Users\user\Desktop\питон\Дазай\piggy2.py')

@bot.command()
async def мояСмерть(ctx):
	i = randint(1,2)
	month = randint(1, 12)
	mon_name = name_month[month]
	interval = int()
	if randint(1, 4) == 1:
		interval = 2100
	else:
		interval = 2030

	yeare = randint(2022, interval)
	days = day_in_month[month]
	day = randint(1, days)
	date_deth = f'{day} {mon_name} {yeare} года'
	if i == 1:
		n = randint(1,13)
		p = deth_info[str(n)]
		answer = f'ты {p} {date_deth}'
		await ctx.send(answer)
	elif i == 2:
		n = randint(1,3)
		p = deth_info2[str(n)]
		answer = f'тебя {p} {date_deth}'
		await ctx.send(answer)




@commands.has_role(889842559487189002)
@bot.command()
async def добарт(ctx, *, content):
    with sqlite3.connect('anime_img.db') as db:
        cursorA = db.cursor()

        cursorA.execute("""CREATE TABLE IF NOT EXISTS imges(id INTEGER, url TEXT)""")
        cursorA.execute("""SELECT id FROM imges""")

        id = cursorA.fetchall()
        idc = []
        for i in id:
            idc.append(int(i[0]))

        id = max(idc) + 1
        cursorA.execute("""INSERT INTO imges(id, url) VALUES(?, ?)""", (id, content,))
        await ctx.send('Арт добавлен')


@bot.command()
async def арты(ctx):
    with sqlite3.connect('anime_img.db') as db:
        cursorA = db.cursor()

        cursorA.execute("""CREATE TABLE IF NOT EXISTS imges(id INTEGER, url TEXT)""")
        cursorA.execute("""SELECT id FROM imges""")

        id = cursorA.fetchall()
        idc = []
        for i in id:
            idc.append(int(i[0]))

        m1 = min(idc)
        m2 = max(idc)
        a = randint(m1, m2)
        cursorA.execute("""SELECT url FROM imges WHERE id = ? """, (a,))
        t = cursorA.fetchone()
        text = t[0]
        emb = discord.Embed(color = 0xff9900, title = 'Рандомный арт')
        emb.set_image(url = str(text))
        await ctx.send(embed = emb)



@commands.has_role(889842559487189002)
@bot.command()
async def добмем(ctx, *, content):
    with sqlite3.connect('memes.db') as db:
        cursorM = db.cursor()

        cursorM.execute("""CREATE TABLE IF NOT EXISTS imges(id INTEGER, url TEXT)""")
        cursorM.execute("""SELECT id FROM imges""")

        id = cursorM.fetchall()
        idc = []
        for i in id:
            idc.append(int(i[0]))

        id = max(idc) + 1
        cursorM.execute("""INSERT INTO imges(id, url) VALUES(?, ?)""", (id, content,))
        await ctx.send('Добавил эту поебень')


@bot.command()
async def мемы(ctx):
    with sqlite3.connect('memes.db') as db:
        cursorM = db.cursor()

        cursorM.execute("""CREATE TABLE IF NOT EXISTS imges(id INTEGER, url TEXT)""")
        cursorM.execute("""SELECT id FROM imges""")

        id = cursorM.fetchall()
        idc = []
        for i in id:
            idc.append(int(i[0]))

        m1 = min(idc)
        m2 = max(idc)
        a = randint(m1, m2)
        cursorM.execute("""SELECT url FROM imges WHERE id = ? """, (a,))
        t = cursorM.fetchone()
        text = t[0]
        emb = discord.Embed(color = 0xff9900, title = 'Рандомный мем')
        emb.set_image(url = str(text))
        await ctx.send(embed = emb)





@commands.has_role(889842559487189002)
@bot.command()
async def добобои(ctx, *, content):
    with sqlite3.connect('wallpaper.db') as db:
        cursorO = db.cursor()

        cursorO.execute("""CREATE TABLE IF NOT EXISTS imges(id INTEGER, url TEXT)""")
        cursorO.execute("""SELECT id FROM imges""")

        id = cursorO.fetchall()
        idc = []
        for i in id:
            idc.append(int(i[0]))

        id = max(idc) + 1
        cursorO.execute("""INSERT INTO imges(id, url) VALUES(?, ?)""", (id, content,))
        await ctx.send('Новые обои добавлены')


@bot.command()
async def обои(ctx):
    with sqlite3.connect('wallpaper.db') as db:
        cursorO = db.cursor()

        cursorO.execute("""CREATE TABLE IF NOT EXISTS imges(id INTEGER, url TEXT)""")
        cursorO.execute("""SELECT id FROM imges""")

        id = cursorO.fetchall()
        idc = []
        for i in id:
            idc.append(int(i[0]))

        m1 = min(idc)
        m2 = max(idc)
        a = randint(m1, m2)
        cursorO.execute("""SELECT url FROM imges WHERE id = ? """, (a,))
        t = cursorO.fetchone()
        text = t[0]
        emb = discord.Embed(color = 0xff9900, title = 'Рандомные обои')
        emb.set_image(url = str(text))
        await ctx.send(embed = emb)




@commands.has_role(889842559487189002)
@bot.command()
async def добаниме(ctx, *, name: str):
    with sqlite3.connect('anime.db') as db:
        cursora = db.cursor()

        cursora.execute("""SELECT id FROM anime WHERE name = ?""", (name,) )
        if cursora.fetchone() is None:

            cursora.execute("""SELECT id FROM anime""")
            id = cursora.fetchall()
            idc = []
            for i in id:
                idc.append(int(i[0]))
            id = max(idc) + 1

            cursora.execute("""INSERT INTO anime(id, name) VALUES (?, ?)""", (id, name))
            await ctx.send(f'Запись данных об {name}')
            await ctx.send(f'Введите url превьюшки')
            msg = await bot.wait_for('message', check = lambda m: m.channel == ctx.channel and m.author.id == ctx.author.id)
            url = msg.content
            cursora.execute("""UPDATE anime SET image = ? WHERE id = ? """, (url, id,))

            await ctx.send('Введите теги')
            msg1 = await bot.wait_for('message', check = lambda m: m.channel == ctx.channel and m.author.id == ctx.author.id)
            tags = msg1.content
            cursora.execute("""UPDATE anime SET tags = ? WHERE id = ? """, (tags, id,))

            await ctx.send('Введите количество серий')
            msg2 = await bot.wait_for('message', check = lambda m: m.channel == ctx.channel and m.author.id == ctx.author.id)
            count = msg2.content
            cursora.execute("""UPDATE anime SET count = ? WHERE id = ? """, (count, id,))

            await ctx.send('Введите оценку')
            msg3 = await bot.wait_for('message', check = lambda m: m.channel == ctx.channel and m.author.id == ctx.author.id)
            est = msg3.content
            cursora.execute("""UPDATE anime SET est = ? WHERE id = ? """, (est, id,))

            await ctx.send('Введите дату релиза')
            msg4 = await bot.wait_for('message', check = lambda m: m.channel == ctx.channel and m.author.id == ctx.author.id)
            dat = msg4.content
            cursora.execute("""UPDATE anime SET dat = ? WHERE id = ? """, (dat, id,))

            await ctx.send(f'Информация об аниме {name} занесена')
        else:
            await ctx.send('Это аниме уже есть в базе данных, используйте функцию редактирования')


@bot.command()
async def раниме(ctx):
    with sqlite3.connect('anime.db') as db:
        cursora = db.cursor()

        cursora.execute("""SELECT id FROM anime""")

        id = cursora.fetchall()
        idc = []
        for i in id:
            idc.append(int(i[0]))

        m1 = min(idc)
        m2 = max(idc)
        a = randint(m1, m2)

        cursora.execute("""SELECT name FROM anime WHERE id = ? """, (a,))
        name = cursora.fetchone()[0]

        cursora.execute("""SELECT image FROM anime WHERE id = ? """, (a,))
        image_url = cursora.fetchone()[0]

        cursora.execute("""SELECT tags FROM anime WHERE id = ? """, (a,))
        tags = cursora.fetchone()[0]

        cursora.execute("""SELECT count FROM anime WHERE id = ? """, (a,))
        count = cursora.fetchone()[0]

        cursora.execute("""SELECT est FROM anime WHERE id = ? """, (a,))
        est = cursora.fetchone()[0]

        cursora.execute("""SELECT dat FROM anime WHERE id = ? """, (a,))
        date = cursora.fetchone()[0]


        emb = discord.Embed(color = 0x07ff00, title = name)
        emb.add_field(name = f'{count} серий', value = tags, inline=True)
        emb.add_field(name = 'оценка', value = est, inline = True)
        emb.set_image(url = image_url)
        emb.set_footer(text = f'дата релиза {date}')

        await ctx.send(embed = emb)

@bot.command()
async def редактинфо(ctx):
    emb = discord.Embed(color = 0x07ff00, title = 'Информация о параметрах редактирования')
    emb.add_field(name = 'image', value='редактирование превью аниме', inline = False)
    emb.add_field(name = 'tags', value='редактирование тегов аниме', inline=  False)
    emb.add_field(name = 'count', value='редактирование количества серий аниме', inline=  False)
    emb.add_field(name = 'est', value='редактирование оценки аниме', inline=  False)
    await ctx.send(embed = emb)

@commands.has_role(889842559487189002)
@bot.command()
async def редактаниме(ctx, *, text):
    with sqlite3.connect('anime.db') as db:
        cursora = db.cursor()
        parametr = text.split(' п: ')[1]
        name = text.split(' п: ')[0]
        cursora.execute("""SELECT id FROM anime WHERE name = ?""", (name,))
        if cursora.fetchone() is None:
            await ctx.send('Аниме не обнаружено, возможно вы не правильно указали имя или его еще не добавили')
        else:
            await ctx.send('введите новое значение параметра')
            msg = await bot.wait_for('message', check = lambda m: m.channel == ctx.channel and m.author.id == ctx.author.id)
            meaning = msg.content
            if parametr == 'image':
                cursora.execute("""UPDATE anime SET image = ? WHERE name = ?""", (parametr, name))
            elif parametr == 'tags':
                cursora.execute("""UPDATE anime SET tags = ? WHERE name = ?""", (parametr, name))
            elif parametr == 'count':
                cursora.execute("""UPDATE anime SET count = ? WHERE name = ?""", (parametr, name))
            elif parametr == 'est':
                cursora.execute("""UPDATE anime SET est = ? WHERE name = ?""", (parametr, name))
        await ctx.send('По идее данные обновлены')


@bot.command()
async def переведи(ctx, lang, *, text: str):
	trans = Translator()
	a = randint(1,8)
	user_id = ctx.author.id
	channel = ctx.channel.id
	dbname = ctx.guild.name + '_achivs.db'
	if text.lower() == 'я из россии':
		await ctx.send('RUSSIA RUSSIA VODKA PUTIN FUCK U PICE OF SHIT')
		await give_ach('russia_vp', user_id, dbname, channel)
	elif a == 1:
		await ctx.send(bad_translator[a])
	elif a == 2:
		await ctx.send(bad_translator[a])
	elif a == 3:
		await ctx.send(bad_translator[a])

	if lang == 'ru':
		result = trans.translate(str(text), dest='ru')
		await ctx.send(f'перевод: {result.text}')
	else:
		if lang in googletrans.LANGUAGES:
			result = trans.translate(str(text), dest=lang)
			await ctx.send(f'перевод: {result.text}, произношение: {result.pronunciation}')
		else:
			await ctx.send('не ебу че за язык')

@bot.command()
async def языки(ctx):
	emb = discord.Embed(title='доступные обозначения языков', color=0xffffff)
	emb1 = discord.Embed(title='доступные обозначения языков 2', color=0xffffff)
	emb2 = discord.Embed(title='доступные обозначения языков 3', color=0xffffff)
	emb3 = discord.Embed(title='доступные обозначения языков 4', color=0xffffff)

	n = 0
	count = 0
	for i in googletrans.LANGUAGES:
		znach = bool()
		if n == 2:
			znach = False
			n = 0
		else:
			znach = True
			n += 1
		if count <= 30:
			emb.add_field(name=f'{i} : {googletrans.LANGUAGES[i]}', value='доступен', inline=znach)
		elif count <= 60 and count > 30:
			emb1.add_field(name=f'{i} : {googletrans.LANGUAGES[i]}', value='доступен', inline=znach)
		elif count <= 100 and count > 60:
			emb2.add_field(name=f'{i} : {googletrans.LANGUAGES[i]}', value='доступен', inline=znach)
		else:
			emb3.add_field(name=f'{i} : {googletrans.LANGUAGES[i]}', value='доступен', inline=znach)

		count += 1

	await ctx.send(embed=emb)
	await ctx.send(embed=emb1)
	await ctx.send(embed=emb2)
	await ctx.send(embed=emb3)

@bot.command()
async def язык(ctx, znach):
	trans = Translator()
	if znach in googletrans.LANGUAGES:
		result = trans.translate(str(googletrans.LANGUAGES[znach]), dest='ru')
		await ctx.send(result.text)
	else:
		lang_in_list = trans.translate(znach, dest='en').text.lower()
		n = False
		for i in googletrans.LANGUAGES:
			# print(googletrans.LANGUAGES[i] + ' <<>> ' + lang_in_list)
			if googletrans.LANGUAGES[i] == lang_in_list:
				await ctx.send(i)
				n = True
				break

		if n == False:
			await ctx.send('ошибка')




@bot.command()
async def кто(ctx, *, user):
	a = len(nicknames)
	variant = randint(1,a)
	if user == 'я':
		if ctx.author.nick == None:
			await ctx.send(f'{ctx.author.name} ты {nicknames[variant]}')
		else:
			await ctx.send(f'{ctx.author.nick} ты {nicknames[variant]}')
	else:
		if user == 'ты':
			user = 'я'
			num_list = [2, 10, 11, 12, 16, 17, 19, 27, 33, 36, 38, 43]
			var = nicknames[num_list[randint(0, len(num_list))]]
			answer = str()
			if var == ', вам надо умереть':
				answer = 'мне надо умереть'
			else:
				answer = f'{user} {var}'

			await ctx.send(answer)
		else:
			await ctx.send(f'{user} {nicknames[variant]}')





@bot.command()
async def стоит(ctx, *, text):
	if list(text)[-1] == '?':
		return
	else:
		a = text.split('или')
		i = len(a)
		variables = { 1: 'первое', 2: 'второе', 3: 'третье', 4: 'четвертое', 5: 'пятое'}
		await ctx.send(f'я думаю {variables[randint(1,i)]}')

@bot.command()
async def когда(ctx, *, text):
	month = randint(1,12)
	mon_name = name_month[month]
	interval = int()
	if randint(1,4) == 1:
		interval = 2100
	else:
		interval = 2030

	yeare = randint(2022, interval)
	days = day_in_month[month]
	day = randint(1,days)
	await ctx.send(f'{day} {mon_name} {yeare} года')


@bot.command()
async def блэкджек(ctx, oper, text = None):
	if oper == 'ставка':
		await ctx.send((randint(10,150) // 5) * 5)
		while True:
			msg = await bot.wait_for('message', check = lambda m: m.channel == ctx.channel and m.author.id == ctx.author.id)
			if msg.content.split()[0] == 'берешь' or msg.content.split()[0] == 'бёрешь':
				num = msg.content.split()[1]
				num = 21 - int(num)
				ans = str
				if num < 5:
					if num == 3:
						a = randint(1, 15)
						if a == 1:
							ans = 'да'
						else:
							ans = 'нет'
					elif num == 2:
						a = randint(1, 15)
						if a == 1:
							ans = 'да'
						else:
							ans = 'нет'
					elif num == 1:
						a = randint(1, 20)
						if a == 1:
							ans = 'да'
						else:
							ans = 'нет'
					elif num == 0:
						ans = 'Ты че ебанулся, нет кшн'
					ans = 'нет'
				elif num <= 6 and num > 4:  # от 15 до 17
					if randint(1, 2) == 2:
						ans = 'да'
					else:
						ans = 'нет'
				else:  # остальное
					if num == 0:
						ans = 'ебанулся? нет кшн'
					else:
						if randint(1, 15) == 15:
							ans = 'нет'
						else:
							ans = 'да'

				await ctx.send(ans)

			elif msg.content.split()[0] == 'результат' or msg.content.split()[0] == 'Результат':
				if msg.content.split()[1] == 'win':
					await ctx.send('Юхууу')
				elif msg.content.split()[1] == 'lose':
					await  ctx.send('Грустно')
				break


@bot.command()
async def монополия(ctx):
	await ctx.send('я хатов')
	while True:
		msg = await bot.wait_for('message', check = lambda m: m.channel == ctx.channel and m.author.id == ctx.author.id)
		if msg.content == 'ходи' or msg.content.split()[0] == 'ходи':
			await ctx.send(randint(2,12))
		elif msg.content == 'покупаешь' or msg.content.split()[0] == 'покупаешь':
			if randint(1,10) in range(1,4):
				await ctx.send('нет')
			else:
				await ctx.send('да')
		elif msg.content == 'стоп игра':
			break

async def stop_casino(channel, dbname, user_id, lose_state, max_wins, all_wins, exp_casino, tryes):
	channel = bot.get_channel(channel)
	await channel.send('надеюсь в следующий раз играть будем со ставками')
	emb = discord.Embed(title='Результаты сессии казино', color=0xbbff00)
	emb.add_field(name='рекорд за эту сессию', value=f'{max_wins}', inline=False)
	emb.set_thumbnail(url='https://cdn.discordapp.com/attachments/896752165899616257/933217543521460304/img_557881.png')
	emb.add_field(name='всего побед в сессии', value=f'{all_wins}', inline=False)
	emb.add_field(name='полученый опыт', value=f'{exp_casino}', inline=False)
	lose_state_1 = 0

	for i in lose_state:
		lose_state_1 += i

	if lose_state_1 != 0:
		lose_state_2 = int(lose_state_1 / len(lose_state))
		print(lose_state_2)

	emb.add_field(name='всего попыток', value=f'{tryes}', inline=False)
	await channel.send(embed=emb)

	if all_wins >= 2:
		if round(lose_state_2) >= 17:
			await give_ach('master_lose_2', user_id, dbname, channel)

	if tryes > 10:
		if round(lose_state_2) < 5:
			await give_ach('lucky_player', dbname, user_id, channel)

	with sqlite3.connect(dbname) as db:
		cur = db.cursor()
		cur.execute("""SELECT most_wins_casino FROM achivs WHERE user_id = ?""", (user_id,))
		if cur.fetchone()[0] < max_wins:
			cur.execute("""UPDATE achivs SET most_wins_casino = ? WHERE user_id = ?""", (max_wins, user_id))

	await give_exp(exp_casino, user_id, dbname, channel.id)

	if max_wins >= 5:
		await channel.send(f'{max_wins} побед подряд. Я хуееею блять. Иди лотерейный билетик купи сука везучая')
		await give_ach('luck_casino', user_id, dbname, channel.id)

	global play_casino
	global channel_casino
	play_casino = False
	channel_casino = 0

def tryes_bd(dbname, user_id):
	with sqlite3.connect(dbname) as db:
		cur = db.cursor()
		cur.execute("""SELECT tryes FROM permissions_casino WHERE user_id = ?""", (user_id,))
		a = cur.fetchone()[0]
		return a

@bot.command()
async def казино(ctx):
	user_id = ctx.author.id
	dbname = ctx.guild.name + '_achivs.db'

	with sqlite3.connect(dbname) as db:
		cur = db.cursor()
		cur.execute("""CREATE TABLE IF NOT EXISTS permissions_casino(user_id INTEGER, tryes INTEGER, perm BOOL)""")



	if await get_perm(user_id, dbname) == True:
		channel = ctx.channel.id
		exp_casino = 0
		win = 0
		all_wins = 0
		max_wins = 0
		tryes = 0
		lose = 0
		lose_state = []
		stupid = 0
		bd_try = tryes_bd(dbname, user_id)

		global play_casino
		global channel_casino
		play_casino = True
		channel_casino = ctx.channel.id
		emb_c = discord.Embed(title='Правила казино', color=0x008bff, description='попробуй угадать число от 1 до 10. После сообщений бота вводите число')
		await ctx.send(embed = emb_c)
		await ctx.send('Введите число')

		while True:
			msg = await bot.wait_for('message', check=lambda m: m.channel == ctx.channel and m.author.id == ctx.author.id)
			a = randint(1,10)
			if msg.content.lower() == 'стоп':
				await stop_casino(channel, dbname, user_id, lose_state, max_wins, all_wins, exp_casino, tryes)
				break

			else:
				try:
					if int(msg.content) in range(1,11):
						if int(msg.content) == a:
							win += 1
							lose_state.append(lose)
							lose = 0
							if win > 1:
								exp_casino += 300

							all_wins += 1
							exp_casino += 150
							await ctx.send(f'вы выиграли. число побед подряд: {win}')
							await ctx.send(f'Общее число побед: {all_wins}')
							await ctx.send('го некст')
							if win > max_wins:
								max_wins = win
						else:
							win = 0
							lose += 1
							if lose >= 20:
								await give_ach('master_lose', user_id, dbname, channel)

							await ctx.send(f'лох, было {a}')
							await ctx.send('го некст')

						tryes += 1
						stupid = 0
						bd_try += 1

						if tryes >= 75:
							await give_ach('azart_player', user_id, dbname, channel)

						if bd_try >= 150:
							with sqlite3.connect(dbname) as db:
								cur = db.cursor()
								cur.execute("""UPDATE permissions_casino SET tryes = ? WHERE user_id = ?""", (bd_try, user_id))
							await ctx.send('Лимит попыток исчерпан')
							await stop_casino(channel, dbname, user_id, lose_state, max_wins, all_wins, exp_casino,tryes)
							break

					else:
						stupid += 1
						if randint(1,2) == 1:
							await ctx.send('число не входит интервал')
						else:
							await ctx.send('Долбаеб? Написано же от 1 до 10 блять')
						if stupid >= 15:
							await give_ach('stupid_player', user_id, dbname, channel)
				except ValueError:
					stupid += 1
					if randint(1,2) == 1:
						await ctx.send('Ты написал что-то не относящееся к казино')
					else:
						await ctx.send('Бля пиши плз то что входит в программу казино')
					if stupid >= 15:
						await give_ach('stupid_player', user_id, dbname, channel)
	else:
		await ctx.send('вы исчерпали лимит попыток')

@bot.command()
async def статус(ctx, user: discord.User = None):
	user_id = int
	user_name = str
	url = str
	if user is None:
		user_id = ctx.author.id
		user_name = ctx.author.name
		url = ctx.author.avatar_url
	else:
		user_id = user.id
		user_name = user.name
		url = user.avatar_url
	dbname = ctx.guild.name + '_achivs' + '.db'
	channel = ctx.channel.id

	exp = int
	lvl = int
	achiv_count = int
	most_wins = int

	with sqlite3.connect(dbname) as db:
		cur = db.cursor()
		cur.execute("""SELECT exp FROM achivs WHERE user_id = ?""", (user_id,))
		if cur.fetchone() is None:
			cur.execute("""INSERT INTO achivs(user_id, lvl, exp, most_wins_casino, blm, sus_dance, free_time, ucraine, pupa, biba, cenz, net_pidor, pidor_full, da_pizda, russian_game, hikki, money_1, money_2, bebra, anton, amogus, luck_casino, master_lose, master_lose_2, azart_player, lucky_player, stupid_player, russia_vp, lh_daz, motivate) VALUES (?, 1, 0, 0, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False, False)""", (user_id,))

		cur.execute("""SELECT exp FROM achivs WHERE user_id = ?""", (user_id,))
		exp = cur.fetchone()[0]
		cur.execute("""SELECT lvl FROM achivs WHERE user_id = ?""", (user_id,))
		lvl = cur.fetchone()[0]
		cur.execute("""SELECT most_wins_casino FROM achivs WHERE user_id = ?""", (user_id,))
		most_wins = cur.fetchone()[0]
		list = []
		cur.execute("""SELECT blm, sus_dance, free_time, ucraine, pupa, biba, cenz, net_pidor, pidor_full, da_pizda, russian_game, hikki, money_1, money_2, bebra, anton, amogus, luck_casino, master_lose, master_lose_2, azart_player, lucky_player, stupid_player, russia_vp, lh_daz, motivate FROM achivs WHERE user_id = ?""", (user_id,))
		list1 = cur.fetchone()
		for i in list1:
			list.append(i)

		achiv_count = list.count(1)

	emb = discord.Embed(title=f'Статус {user_name}', color=0x07ff00)
	emb.set_thumbnail(url=url)
	emb.add_field(name=f'lvl {lvl}', value=f'Опыт {exp} / {lvls[lvl]}', inline=False)
	emb.add_field(name='Рекорд в казино', value=most_wins, inline=False)
	emb.add_field(name='Собранные достижения', value=f'{achiv_count}/25', inline=False)

	await ctx.send(embed = emb)



@bot.event
async def on_raw_reaction_add(payload):
	if payload.message_id == test_config.POST_ID:
		channel = bot.get_channel(payload.channel_id)  # получаем объект канала
		message = await channel.fetch_message(payload.message_id)  # получаем объект сообщения
		member = payload.member  # получаем объект пользователя который поставил реакцию
		#print(member)

		try:
			emoji = str(payload.emoji)  # эмоджик который выбрал юзер
			role = utils.get(message.guild.roles, id=test_config.ROLES[emoji])  # объект выбранной роли (если есть)

			await member.add_roles(role)
			#print('[SUCCESS] User {0.display_name} has been granted with role {1.name}'.format(member, role))

		except KeyError as e:
			print('[ERROR] KeyError, no role found for ' + emoji)
		except Exception as e:
			print(repr(e))

	elif payload.message_id == test_config.POST_ID_G:
		channel = bot.get_channel(payload.channel_id)  # получаем объект канала
		message = await channel.fetch_message(payload.message_id)  # получаем объект сообщения
		member = payload.member  # получаем объект пользователя который поставил реакцию
		#print(member)

		try:
			emoji = str(payload.emoji)  # эмоджик который выбрал юзер
			role = utils.get(message.guild.roles, id=test_config.ROLES_G[emoji])  # объект выбранной роли (если есть)

			await member.add_roles(role)
			#print('[SUCCESS] User {0.display_name} has been granted with role {1.name}'.format(member, role))

		except KeyError as e:
			print('[ERROR] KeyError, no role found for ' + emoji)
		except Exception as e:
			print(repr(e))

@bot.event
async def on_raw_reaction_remove(payload):
	if payload.message_id == test_config.POST_ID:
		channel = bot.get_channel(payload.channel_id)  # получаем id канала
		message = await channel.fetch_message(payload.message_id)  # получаем id сообщения
		user_id = payload.user_id  # по сути эта херня не нужна, но на всякий случай не трож
		member = await (await bot.fetch_guild(payload.guild_id)).fetch_member(payload.user_id)
		#print(member, user_id)

		try:
			emoji = str(payload.emoji)  # эмоджик который выбрал юзер
			role = utils.get(message.guild.roles, id=test_config.ROLES[emoji])  # объект выбранной роли (если есть)

			await member.remove_roles(role)
			#print('[SUCCESS] Role {1.name} has been remove for user {0.display_name}'.format(member, role))


		except KeyError as e:
			print('[ERROR] KeyError, no role found for ' + emoji)

		except Exception as e:
			print(repr(e))

	elif payload.message_id == test_config.POST_ID_G:
		channel = bot.get_channel(payload.channel_id)  # получаем id канала
		message = await channel.fetch_message(payload.message_id)  # получаем id сообщения
		user_id = payload.user_id  # по сути эта херня не нужна, но на всякий случай не трож
		member = await (await bot.fetch_guild(payload.guild_id)).fetch_member(payload.user_id)
		#print(member, user_id)

		try:
			emoji = str(payload.emoji)  # эмоджик который выбрал юзер
			role = utils.get(message.guild.roles, id=test_config.ROLES_G[emoji])  # объект выбранной роли (если есть)

			await member.remove_roles(role)
			#print('[SUCCESS] Role {1.name} has been remove for user {0.display_name}'.format(member, role))


		except KeyError as e:
			print('[ERROR] KeyError, no role found for ' + emoji)

		except Exception as e:
			print(repr(e))


bot.run(settings['token'])

a = input()
